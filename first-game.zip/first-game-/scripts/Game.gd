extends Node
## Autoload "Game": high-level persistent state only.
## No combat, AI, or UI logic here — just progress + player build.
## LevelManager / Main handle flow; they read/write this.

signal progress_changed

var current_level: int = 0
var score: int = 0
var player_max_health: int = Balance.PLAYER_MAX_HEALTH
var player_health: int = Balance.PLAYER_MAX_HEALTH
var player_poisons: int = Balance.PLAYER_START_POISONS

func reset_run() -> void:
	current_level = 0
	score = 0
	player_max_health = Balance.PLAYER_MAX_HEALTH
	player_health = player_max_health
	player_poisons = Balance.PLAYER_START_POISONS
	emit_signal("progress_changed")

func add_score(amount: int) -> void:
	score += amount
	emit_signal("progress_changed")

func heal_player(amount: int) -> void:
	player_health = mini(player_max_health, player_health + amount)
	emit_signal("progress_changed")

func grow_max_health(amount: int = 1) -> void:
	player_max_health = mini(10, player_max_health + amount)
	player_health = mini(player_max_health, player_health + amount)
	emit_signal("progress_changed")

func set_health(hp: int, max_hp: int) -> void:
	player_max_health = max_hp
	player_health = clampi(hp, 0, max_hp)
	emit_signal("progress_changed")

func set_poisons(n: int) -> void:
	player_poisons = clampi(n, 0, Balance.PLAYER_MAX_POISONS)
	emit_signal("progress_changed")

func add_poison(n: int = 1) -> void:
	set_poisons(player_poisons + n)

func use_poison() -> bool:
	if player_poisons <= 0:
		return false
	player_poisons -= 1
	emit_signal("progress_changed")
	return true

func advance_level() -> bool:
	# Returns true if there IS a next level.
	current_level += 1
	# Small heal between levels so runs stay fair.
	player_health = mini(player_max_health, player_health + 1)
	emit_signal("progress_changed")
	return current_level < Balance.level_count()
