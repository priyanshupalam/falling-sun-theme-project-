extends CharacterBody2D
## Prince player: movement, jumping, sword combat, health, states.
## States: idle, run, jump, fall, attack, hurt, death.
## Uses SwordHitbox (Area2D) so damage is hitbox-based, one hit per swing.

signal health_changed(hp: int, max_hp: int)
signal poisons_changed(count: int)
signal died
signal attack_started(facing: int)
signal throw_requested(origin: Vector2, direction: int)
signal special_changed(remaining: float, total: float)
signal special_shock(pos: Vector2, radius: float)

enum State { IDLE, RUN, JUMP, FALL, ATTACK, HURT, DEATH, SPECIAL }

var state: int = State.IDLE
var max_health: int = Balance.PLAYER_MAX_HEALTH
var health: int = Balance.PLAYER_MAX_HEALTH
var sword_damage: int = Balance.PLAYER_SWORD_DAMAGE
var facing: int = 1  # 1 = right, -1 = left

var _attack_cd: float = 0.0
var _attack_active: float = 0.0
var _invuln: float = 0.0
var _hit_ids: Dictionary = {}
var _dead: bool = false
var _hurt_t: float = 0.0
# Royal Slash (Q special): charge-up then a wide heavy strike.
var _special_cd: float = 0.0
var _special_t: float = 0.0
var _special_phase: String = ""  # "" | "charge" | "strike"
var _special_ids: Dictionary = {}
var _last_special_sec: int = -1

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var sword_hitbox: Area2D = $SwordHitbox
@onready var sword_shape: CollisionShape2D = $SwordHitbox/CollisionShape2D
@onready var special_hitbox: Area2D = $SpecialHitbox
@onready var special_shape: CollisionShape2D = $SpecialHitbox/CollisionShape2D
@onready var camera: Camera2D = $Camera2D

func _ready() -> void:
	add_to_group("player")
	PlaceholderArt.setup_player(sprite)
	max_health = Game.player_max_health
	health = Game.player_health
	_sync_game()
	# Sword hitbox: detect enemy bodies. Easy to tweak in Balance.SWORD_RANGE.
	_update_sword_shape()
	sword_hitbox.monitoring = true
	sword_hitbox.monitorable = false
	sword_hitbox.body_entered.connect(_on_sword_body)
	# Royal Slash hitbox: same Area2D pattern, bigger rect (Balance.ROYAL_*).
	_update_special_shape()
	special_hitbox.monitoring = true
	special_hitbox.monitorable = false
	special_hitbox.body_entered.connect(_on_special_body)
	# Start synced with HUD.
	emit_signal("health_changed", health, max_health)
	emit_signal("poisons_changed", Game.player_poisons)
	emit_signal("special_changed", 0.0, Balance.ROYAL_COOLDOWN)

func _update_special_shape() -> void:
	var rect := RectangleShape2D.new()
	rect.size = Vector2(Balance.ROYAL_RANGE, Balance.ROYAL_ARC_HEIGHT)
	special_shape.shape = rect
	special_shape.position = Vector2(Balance.ROYAL_RANGE * 0.5 + 12.0, -10.0)

func _update_sword_shape() -> void:
	var rect := RectangleShape2D.new()
	rect.size = Vector2(Balance.SWORD_RANGE, Balance.SWORD_ARC_HEIGHT)
	sword_shape.shape = rect
	sword_shape.position = Vector2(Balance.SWORD_RANGE * 0.5 + 12.0, -6.0)

func _physics_process(delta: float) -> void:
	if _dead:
		return
	_attack_cd = maxf(0.0, _attack_cd - delta)
	_invuln = maxf(0.0, _invuln - delta)
	_attack_active = maxf(0.0, _attack_active - delta)
	_tick_special_cooldown(delta)

	# Gravity.
	if not is_on_floor():
		velocity.y += Balance.PLAYER_GRAVITY * delta

	var dir := Input.get_axis("move_left", "move_right")
	var attacking := state == State.ATTACK and _attack_active > 0.0
	var busy := attacking or state == State.SPECIAL

	if state != State.HURT or _hurt_t <= 0.0:
		if dir != 0.0 and not busy:
			velocity.x = dir * Balance.PLAYER_MOVE_SPEED
			facing = 1 if dir > 0.0 else -1
		elif busy:
			velocity.x = move_toward(velocity.x, 0.0, Balance.PLAYER_MOVE_SPEED * 8.0 * delta)
		else:
			velocity.x = move_toward(velocity.x, 0.0, Balance.PLAYER_MOVE_SPEED * 10.0 * delta)
	else:
		_hurt_t -= delta

	# Royal Slash charge/strike timing.
	_tick_special(delta)

	# Jump.
	if Input.is_action_just_pressed("jump") and is_on_floor() and not busy:
		velocity.y = Balance.PLAYER_JUMP_VELOCITY
		AudioManager.play_sfx("jump")

	# Attack.
	if Input.is_action_just_pressed("attack"):
		try_attack()

	# Royal Slash special.
	if Input.is_action_just_pressed("special_attack"):
		try_special()

	# Use item (poison).
	if Input.is_action_just_pressed("use_item"):
		try_throw_poison()

	move_and_slide()
	_update_facing_visual()
	_update_state()
	_update_animation()
	# Continuous overlap check during active frames.
	if _attack_active > 0.0:
		for body in sword_hitbox.get_overlapping_bodies():
			_damage_body(body)
	if _special_phase == "strike":
		for body in special_hitbox.get_overlapping_bodies():
			_damage_special(body)
	# Damage flash.
	sprite.modulate.a = 0.45 + 0.55 * abs(sin(Time.get_ticks_msec() / 90.0)) if _invuln > 0.0 else 1.0

func _update_facing_visual() -> void:
	sprite.flip_h = facing < 0
	sword_shape.position.x = absf(sword_shape.position.x) * float(facing)
	special_shape.position.x = absf(special_shape.position.x) * float(facing)

func _update_state() -> void:
	if state == State.SPECIAL:
		return  # Charge/strike timing is driven by _tick_special().
	if state == State.ATTACK and _attack_active > 0.0:
		return
	if state == State.ATTACK and _attack_active <= 0.0:
		state = State.IDLE
	if state == State.HURT and _hurt_t > 0.0:
		return
	if not is_on_floor():
		state = State.JUMP if velocity.y < 0.0 else State.FALL
	elif absf(velocity.x) > 20.0:
		state = State.RUN
	else:
		state = State.IDLE

func _update_animation() -> void:
	if _dead:
		return
	match state:
		State.IDLE:
			_play("idle")
		State.RUN:
			_play("run")
		State.JUMP:
			_play("jump")
		State.FALL:
			_play("fall")
		State.ATTACK:
			_play("attack")
		State.SPECIAL:
			_play("special")
		State.HURT:
			_play("hurt")

func _play(anim: String) -> void:
	if sprite.animation != anim or not sprite.is_playing():
		if sprite.sprite_frames != null and sprite.sprite_frames.has_animation(anim):
			sprite.play(anim)

# ---------- COMBAT ----------
func try_attack() -> bool:
	if _dead or _attack_cd > 0.0:
		return false
	if state == State.SPECIAL:
		return false
	if state == State.HURT and _hurt_t > 0.0:
		return false
	_attack_cd = Balance.PLAYER_ATTACK_COOLDOWN
	_attack_active = 0.18
	_hit_ids.clear()
	state = State.ATTACK
	_play("attack")
	AudioManager.play_sfx("swing")
	_spawn_slash_visual()
	emit_signal("attack_started", facing)
	return true

func _on_sword_body(body) -> void:
	if _attack_active > 0.0:
		_damage_body(body)

func _damage_body(body) -> void:
	if body == null or not is_instance_valid(body):
		return
	if _hit_ids.has(body.get_instance_id()):
		return
	if body.is_in_group("enemies") and body.has_method("take_damage"):
		var from := Vector2(float(facing), 0.0)
		_hit_ids[body.get_instance_id()] = true
		body.take_damage(sword_damage, from)

# ---------- ROYAL SLASH (Q special attack) ----------
# Charge 0.4s, then one wide heavy strike. Cooldown starts on the strike,
# so being hit out of the charge doesn't waste it. One hit per enemy
# per activation via _special_ids. Bosses take heavy damage + stagger
# through the `heavy` flag on take_damage().
func try_special() -> bool:
	if _dead or state == State.SPECIAL:
		return false
	if _special_cd > 0.0:
		return false
	if state == State.HURT and _hurt_t > 0.0:
		return false
	_special_phase = "charge"
	_special_t = Balance.ROYAL_CHARGE_TIME
	_special_ids.clear()
	_attack_active = 0.0  # Cancel any normal swing in progress.
	state = State.SPECIAL
	_play("special")
	AudioManager.play_sfx("charge")
	return true

func _tick_special_cooldown(delta: float) -> void:
	if _special_cd <= 0.0:
		return
	_special_cd = maxf(0.0, _special_cd - delta)
	var sec := int(ceil(_special_cd))
	if sec != _last_special_sec:
		_last_special_sec = sec
		emit_signal("special_changed", _special_cd, Balance.ROYAL_COOLDOWN)
	if _special_cd <= 0.0:
		_last_special_sec = -1
		emit_signal("special_changed", 0.0, Balance.ROYAL_COOLDOWN)

func _tick_special(delta: float) -> void:
	if state != State.SPECIAL:
		return
	_special_t -= delta
	if _special_phase == "charge" and _special_t <= 0.0:
		_do_special_strike()
	elif _special_phase == "strike" and _special_t <= 0.0:
		_special_phase = ""
		state = State.IDLE

func _do_special_strike() -> void:
	_special_phase = "strike"
	_special_t = Balance.ROYAL_STRIKE_TIME
	_special_cd = Balance.ROYAL_COOLDOWN
	_last_special_sec = int(ceil(_special_cd))
	emit_signal("special_changed", _special_cd, Balance.ROYAL_COOLDOWN)
	AudioManager.play_sfx("royal_slash")
	# Big placeholder arc visual (swap RoyalSlashEffect for sprite art later).
	var SlashFX := load("res://scripts/effects/RoyalSlashEffect.gd")
	SlashFX.spawn(get_parent(), global_position + Vector2(0, -20), facing, Balance.ROYAL_RANGE)
	emit_signal("special_shock", global_position, Balance.ROYAL_RANGE)
	for body in special_hitbox.get_overlapping_bodies():
		_damage_special(body)

func _on_special_body(body) -> void:
	if _special_phase == "strike":
		_damage_special(body)

func _damage_special(body) -> void:
	if body == null or not is_instance_valid(body):
		return
	if _special_ids.has(body.get_instance_id()):
		return
	if body.is_in_group("enemies") and body.has_method("take_damage"):
		var from := Vector2(float(facing), 0.0)
		_special_ids[body.get_instance_id()] = true
		if body.is_in_group("boss"):
			body.take_damage(Balance.ROYAL_BOSS_DAMAGE, from, true)
		else:
			body.take_damage(Balance.ROYAL_DAMAGE, from, true)

func _cancel_special() -> void:
	_special_phase = ""
	_special_t = 0.0

func try_throw_poison() -> bool:
	if _dead:
		return false
	if not Game.use_poison():
		return false
	var origin := global_position + Vector2(float(facing) * 24.0, -30.0)
	emit_signal("throw_requested", origin, facing)
	emit_signal("poisons_changed", Game.player_poisons)
	AudioManager.play_sfx("potion_throw")
	return true

func _spawn_slash_visual() -> void:
	var slash := Node2D.new()
	slash.position = Vector2(float(facing) * 44.0, -8.0)
	var line := Line2D.new()
	line.points = PackedVector2Array([Vector2(-22, -18), Vector2(0, 0), Vector2(-22, 18)])
	line.width = 7.0
	line.default_color = Color(1.0, 0.95, 0.7, 0.95)
	add_child(slash)
	slash.add_child(line)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(line, "modulate:a", 0.0, 0.18)
	tw.tween_property(slash, "scale", Vector2(1.4, 1.4), 0.18)
	tw.chain().tween_callback(slash.queue_free)

# ---------- HEALTH ----------
func take_damage(amount: int, from_dir: Vector2 = Vector2.ZERO) -> void:
	if _dead or _invuln > 0.0:
		return
	_cancel_special()  # Getting hit interrupts the Royal Slash charge.
	health = maxi(0, health - amount)
	_invuln = Balance.PLAYER_INVULN_TIME
	_hurt_t = 0.28
	state = State.HURT
	_play("hurt")
	# Knockback away from source.
	velocity.x = -signf(from_dir.x if from_dir.x != 0.0 else float(facing)) * 220.0
	if is_on_floor():
		velocity.y = -180.0
	AudioManager.play_sfx("player_hurt")
	Game.set_health(health, max_health)
	emit_signal("health_changed", health, max_health)
	if health <= 0:
		_die()

func heal(amount: int) -> void:
	if _dead:
		return
	health = mini(max_health, health + amount)
	Game.set_health(health, max_health)
	emit_signal("health_changed", health, max_health)

func add_max_health(amount: int = 1) -> void:
	max_health = mini(10, max_health + amount)
	health = mini(max_health, health + amount)
	Game.set_health(health, max_health)
	emit_signal("health_changed", health, max_health)

func sync_poisons() -> void:
	emit_signal("poisons_changed", Game.player_poisons)

func _die() -> void:
	_dead = true
	state = State.DEATH
	_play("death")
	velocity = Vector2.ZERO
	AudioManager.play_sfx("gameover")
	emit_signal("died")

func _sync_game() -> void:
	Game.player_max_health = max_health
	Game.player_health = health

func is_alive() -> bool:
	return not _dead
