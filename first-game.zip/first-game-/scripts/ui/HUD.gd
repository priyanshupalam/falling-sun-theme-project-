extends Control
## In-game HUD: hearts, level/wave, score, poisons, boss bar, banners.
## Pure presentation — Main.gd feeds it via the methods below.

var hearts_label: Label
var info_label: Label
var score_label: Label
var poison_label: Label
var special_title: Label
var special_status: Label
var boss_box: VBoxContainer
var boss_name: Label
var boss_bar: ProgressBar
var banner_title: Label
var banner_sub: Label
var banner_box: VBoxContainer
var _banner_tw: Tween = null

func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_build_topbar()
	_build_bossbar()
	_build_banner()

func _mk_label(text: String, size: int, color: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("shadow_offset_x", 2)
	l.add_theme_constant_override("shadow_offset_y", 2)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _build_topbar() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_preset(Control.PRESET_TOP_WIDE)
	margin.add_theme_constant_override("margin_left", 16)
	margin.add_theme_constant_override("margin_right", 16)
	margin.add_theme_constant_override("margin_top", 10)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(margin)
	var bar := HBoxContainer.new()
	bar.alignment = BoxContainer.ALIGNMENT_BEGIN
	bar.add_theme_constant_override("separation", 24)
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(bar)
	hearts_label = _mk_label("", 30, Color(1, 0.35, 0.45))
	hearts_label.custom_minimum_size = Vector2(220, 0)
	bar.add_child(hearts_label)
	info_label = _mk_label("", 22)
	info_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bar.add_child(info_label)
	var right := VBoxContainer.new()
	right.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.add_child(right)
	score_label = _mk_label("Score 0", 20, Color(1, 0.9, 0.5))
	score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	right.add_child(score_label)
	poison_label = _mk_label("", 20, Color(0.6, 1, 0.6))
	poison_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	right.add_child(poison_label)
	# Royal Slash cooldown indicator (artwork-swappable: plain Labels).
	special_title = _mk_label("ROYAL SLASH [Q]", 18, Color(1, 0.85, 0.4))
	special_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	right.add_child(special_title)
	special_status = _mk_label("READY", 20, Color(1, 0.9, 0.4))
	special_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	right.add_child(special_status)

func _build_bossbar() -> void:
	boss_box = VBoxContainer.new()
	boss_box.set_anchors_preset(Control.PRESET_CENTER_TOP)
	boss_box.position = Vector2(-260, 64)
	boss_box.custom_minimum_size = Vector2(520, 0)
	boss_box.visible = false
	boss_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(boss_box)
	boss_name = _mk_label("THE SCIENTIST", 20, Color(1, 0.4, 0.4))
	boss_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	boss_box.add_child(boss_name)
	boss_bar = ProgressBar.new()
	boss_bar.custom_minimum_size = Vector2(520, 22)
	boss_bar.max_value = 100
	boss_bar.value = 100
	boss_bar.show_percentage = false
	boss_box.add_child(boss_bar)

func _build_banner() -> void:
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(center)
	banner_box = VBoxContainer.new()
	banner_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(banner_box)
	banner_title = _mk_label("", 64, Color(1, 0.95, 0.8))
	banner_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner_box.add_child(banner_title)
	banner_sub = _mk_label("", 26, Color(0.9, 0.9, 0.9))
	banner_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner_box.add_child(banner_sub)
	banner_box.modulate.a = 0.0

# ---------- API ----------
func set_hearts(hp: int, max_hp: int) -> void:
	var s := ""
	for i in max_hp:
		s += "♥ " if i < hp else "♡ "
	hearts_label.text = s.strip_edges()

func set_level(text: String) -> void:
	# Wave text is composed separately; store level part via tag.
	info_label.text = text

func set_wave(text: String) -> void:
	# Main composes full "LEVEL x — WAVE y/z" string and calls set_level.
	info_label.text = text

func set_score(n: int) -> void:
	score_label.text = "Score %d" % n

func set_poisons(n: int) -> void:
	if n > 0:
		poison_label.text = "Poison x%d  [E]" % n
	else:
		poison_label.text = "Poison x0"

func set_special(remaining: float, _total: float) -> void:
	if remaining <= 0.0:
		special_status.text = "READY"
		special_status.add_theme_color_override("font_color", Color(1, 0.9, 0.4))
	else:
		special_status.text = "%.1fs" % remaining
		special_status.add_theme_color_override("font_color", Color(0.55, 0.55, 0.6))

func show_boss(bname: String, hp: int, max_hp: int) -> void:
	boss_box.visible = true
	boss_name.text = bname
	boss_bar.max_value = max_hp
	boss_bar.value = hp

func update_boss(hp: int, max_hp: int) -> void:
	boss_bar.max_value = max_hp
	boss_bar.value = hp

func hide_boss() -> void:
	boss_box.visible = false

func announce(title: String, subtitle: String = "", hold: float = 1.6) -> void:
	banner_title.text = title
	banner_sub.text = subtitle
	if _banner_tw != null and _banner_tw.is_valid():
		_banner_tw.kill()
	banner_box.modulate.a = 0.0
	_banner_tw = create_tween()
	_banner_tw.tween_property(banner_box, "modulate:a", 1.0, 0.25)
	_banner_tw.tween_interval(hold)
	_banner_tw.tween_property(banner_box, "modulate:a", 0.0, 0.4)

func clear_banner() -> void:
	if _banner_tw != null and _banner_tw.is_valid():
		_banner_tw.kill()
	banner_box.modulate.a = 0.0
