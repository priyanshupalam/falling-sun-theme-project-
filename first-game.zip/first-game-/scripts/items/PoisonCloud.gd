extends Area2D
## Poison splash cloud: damages all enemies inside radius over time.
## Stats from Balance (radius / duration / tick / damage).

var _time_left: float = Balance.POISON_CLOUD_DURATION
var _tick_cd: float = 0.0
var _radius: float = Balance.POISON_CLOUD_RADIUS
var _active: bool = false
var _visual: Sprite2D
var _t: float = 0.0

func _ready() -> void:
	add_to_group("hazards")
	collision_layer = 0
	collision_mask = 1
	monitoring = true
	# Visual built in code but trivially replaceable: swap this Sprite2D's
	# texture with your own splash art in scenes/effects/PoisonCloud.tscn.
	_visual = Sprite2D.new()
	_visual.texture = PlaceholderArt.circle_texture(Color(0.25, 0.8, 0.2, 0.55), 128)
	var s := _radius * 2.0 / 128.0
	_visual.scale = Vector2(s, s * 0.7)
	add_child(_visual)
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = _radius
	shape.shape = circle
	add_child(shape)
	# Start small and grow (splash feel).
	scale = Vector2(0.3, 0.3)

func activate() -> void:
	_active = true
	_time_left = Balance.POISON_CLOUD_DURATION
	var tw := create_tween()
	tw.tween_property(self, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK)

func _process(delta: float) -> void:
	if not _active:
		return
	_t += delta
	_time_left -= delta
	_tick_cd -= delta
	# Bubble pulse.
	if _visual != null:
		_visual.modulate.a = 0.45 + 0.2 * sin(_t * 6.0)
	# Damage tick.
	if _tick_cd <= 0.0:
		_tick_cd = Balance.POISON_CLOUD_TICK
		_burn_tick()
	# Expire.
	if _time_left <= 0.0:
		var tw := create_tween()
		tw.tween_property(self, "modulate:a", 0.0, 0.4)
		tw.tween_callback(queue_free)
		_active = false

func _burn_tick() -> void:
	for body in get_overlapping_bodies():
		if body.is_in_group("enemies") and body.has_method("take_damage"):
			var dir := (body.global_position - global_position).normalized()
			# Bosses take their own tuned value; everyone else the normal one.
			var dmg := Balance.POISON_CLOUD_DAMAGE
			if body.is_in_group("boss"):
				dmg = int(Balance.BOSS_POISON_DAMAGE)
			body.call("take_damage", dmg, dir)
