extends Area2D
## Thrown poison bottle. Arcs forward, splashes into a PoisonCloud on
## landing on ground OR touching an enemy.
## Spawned by Level when player uses a poison (signal throw_requested).

var direction: int = 1
var velocity: Vector2 = Vector2.ZERO
var _landed: bool = false

const CloudScene: PackedScene = preload("res://scenes/effects/PoisonCloud.tscn")

func _ready() -> void:
	add_to_group("player_projectiles")
	collision_layer = 0
	collision_mask = 1
	monitoring = true
	velocity = Vector2(float(direction) * 380.0, -320.0)
	body_entered.connect(_on_body)
	# Visual: small green flask icon.
	var spr := Sprite2D.new()
	spr.texture = PlaceholderArt.item_texture("poison")
	spr.scale = Vector2(0.9, 0.9)
	add_child(spr)
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 10.0
	shape.shape = circle
	add_child(shape)

func launch(from: Vector2, dir: int) -> void:
	global_position = from
	direction = dir
	velocity = Vector2(float(dir) * 380.0, -320.0)

func _physics_process(delta: float) -> void:
	if _landed:
		return
	velocity.y += 1100.0 * delta
	position += velocity * delta
	rotation += float(direction) * 6.0 * delta
	# Safety splash: ground top sits near y=80 in every level, and
	# body_entered fires first in the normal case.
	if global_position.y > 72.0:
		_landed = true
		_splash()

func _on_body(body) -> void:
	if _landed:
		return
	if body.is_in_group("player"):
		return  # Don't detonate on the thrower.
	_landed = true
	_splash()

func _splash() -> void:
	AudioManager.play_sfx("poison")
	var parent := get_parent()
	if parent == null:
		queue_free()
		return
	var cloud = CloudScene.instantiate()
	parent.call_deferred("add_child", cloud)
	# Deferred so parent transform is ready; set position next frame.
	await get_tree().process_frame
	if is_instance_valid(cloud) and cloud.has_method("activate"):
		cloud.set("global_position", global_position)
		cloud.call("activate")
	queue_free()
