extends Area2D
## Generic pickup. One scene handles medkit / heart / poison.
## Expandable: add a new `kind` string + effect in apply_to_player(),
## then list it in Balance.DROPS. No player-code changes needed.
## Kinds: "medkit" (heal 2), "heart" (+1 max & heal), "poison" (+1 bottle).

signal collected(kind: String)

@export var kind: String = "medkit"
## Optional despawn timer (seconds). -1 = stays forever (normal drops).
## Boss-dropped bottles set this from Balance.BOSS_POISON_LIFETIME.
var lifetime: float = -1.0
var _t: float = 0.0
var _age: float = 0.0
var _base_y: float = 0.0
var _taken: bool = false
var _glow: Sprite2D = null

@onready var sprite: Sprite2D = $Sprite2D

func _ready() -> void:
	add_to_group("pickups")
	collision_layer = 0
	collision_mask = 1
	monitoring = true
	monitorable = false
	_base_y = position.y
	_refresh_visual()
	_update_poison_group()
	body_entered.connect(_on_body)

func setup(p_kind: String) -> void:
	kind = p_kind
	if is_node_ready():
		_refresh_visual()
		_update_poison_group()

func _update_poison_group() -> void:
	# Lets the Scientist cap live bottles via get_nodes_in_group().
	if kind == "poison":
		if not is_in_group("poison_bottles"):
			add_to_group("poison_bottles")
	elif is_in_group("poison_bottles"):
		remove_from_group("poison_bottles")

func _refresh_visual() -> void:
	sprite.texture = PlaceholderArt.item_texture(kind)
	# Tint pulse per kind for readability.
	match kind:
		"medkit":
			sprite.modulate = Color.WHITE
		"heart":
			sprite.modulate = Color(1.2, 0.9, 0.9)
		"poison":
			sprite.modulate = Color(0.9, 1.2, 0.9)
	_make_glow()

func _make_glow() -> void:
	# Soft procedural halo so poison bottles read clearly on the ground
	# (boss drops especially). Texture-only; swap for sprite art freely.
	if kind != "poison" or _glow != null:
		return
	_glow = Sprite2D.new()
	_glow.texture = PlaceholderArt.circle_texture(Color(0.4, 1.0, 0.35, 0.45), 48)
	_glow.z_index = -1
	add_child(_glow)

func _process(delta: float) -> void:
	_t += delta
	sprite.position.y = sin(_t * 3.0) * 5.0
	sprite.rotation = sin(_t * 1.7) * 0.12
	if _glow != null:
		var s := 1.6 + 0.2 * sin(_t * 4.0)
		_glow.scale = Vector2(s, s)
	if lifetime > 0.0:
		_age += delta
		var left := lifetime - _age
		if left <= 0.0:
			queue_free()
			return
		if left < 2.0 and _taken == false:
			# Blink out during the last 2 seconds.
			var a: float = 0.35 + 0.65 * abs(sin(_t * 12.0))
			sprite.modulate.a = a
			if _glow != null:
				_glow.modulate.a = a * 0.5

func _on_body(body) -> void:
	if _taken:
		return
	if not body.is_in_group("player"):
		return
	if not body.has_method("heal"):
		return
	_taken = true
	apply_to_player(body)
	AudioManager.play_sfx("pickup")
	emit_signal("collected", kind)
	queue_free()

func apply_to_player(player) -> void:
	match kind:
		"medkit":
			player.heal(Balance.MEDKIT_HEAL)
		"heart":
			player.add_max_health(1)
		"poison":
			Game.add_poison(1)
			if player.has_method("sync_poisons"):
				player.sync_poisons()
		_:
			player.heal(1)
