extends Node2D
## One-shot hit spark / slash / death poof.
## Spawn via HitSpark.spawn(parent, pos, color, size).
## Replace visuals later with your own particle scene — same API.

static func spawn(parent: Node, pos: Vector2, color: Color = Color(1, 0.9, 0.5), size: float = 1.0) -> Node2D:
	var fx := Node2D.new()
	fx.set_script(load("res://scripts/effects/HitSpark.gd"))
	fx.set("spark_color", color)
	fx.set("spark_size", size)
	parent.add_child(fx)
	fx.global_position = pos
	return fx

var spark_color: Color = Color(1, 0.9, 0.5)
var spark_size: float = 1.0
var _t: float = 0.0

func _ready() -> void:
	z_index = 20

func _process(delta: float) -> void:
	_t += delta
	queue_redraw()
	if _t > 0.25:
		queue_free()

func _draw() -> void:
	var a := 1.0 - _t / 0.25
	var c := Color(spark_color.r, spark_color.g, spark_color.b, a)
	var r := (6.0 + _t * 160.0) * spark_size
	draw_arc(Vector2.ZERO, r, -0.6, 0.6, 12, c, 5.0 * spark_size)
	draw_arc(Vector2.ZERO, r * 0.7, 2.5, 3.7, 12, c, 4.0 * spark_size)
	draw_circle(Vector2.ZERO, 5.0 * spark_size * a + 1.0, c)
