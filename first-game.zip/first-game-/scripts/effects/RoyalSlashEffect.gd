extends Node2D
## Royal Slash visual: big gold crescent + shockwave ring, auto-frees.
## Spawn via RoyalSlashEffect.spawn(parent, pos, facing, slash_range).
##
## HOW TO REPLACE WITH YOUR OWN ART:
## Keep the same static spawn() signature and swap the _draw() body
## for a Sprite2D/AnimatedSheet (e.g. a "royal_slash" SpriteFrames
## animation in res://assets/effects/). No gameplay code changes needed.

const DURATION: float = 0.35

static func spawn(parent: Node, pos: Vector2, facing: int, slash_range: float) -> Node2D:
	var fx := Node2D.new()
	fx.set_script(load("res://scripts/effects/RoyalSlashEffect.gd"))
	fx.set("slash_range", slash_range)
	fx.set("facing_dir", facing)
	parent.add_child(fx)
	fx.global_position = pos
	return fx

var slash_range: float = 175.0
var facing_dir: int = 1
var _t: float = 0.0

func _ready() -> void:
	z_index = 21

func _process(delta: float) -> void:
	_t += delta
	queue_redraw()
	if _t >= DURATION:
		queue_free()

func _draw() -> void:
	var k := _t / DURATION  # 0 -> 1
	var a := 1.0 - k
	var dir := float(facing_dir if facing_dir != 0 else 1)
	var gold := Color(1.0, 0.85, 0.35, 0.95 * a)
	var pale := Color(1.0, 0.98, 0.85, 0.9 * a)
	var white := Color(1, 1, 1, a)
	# Expanding outer crescent.
	var r := 30.0 + k * slash_range
	var w := lerpf(14.0, 5.0, k)
	if dir > 0.0:
		draw_arc(Vector2.ZERO, r, -0.9, 0.9, 24, gold, w)
		draw_arc(Vector2.ZERO, r * 0.8, -0.7, 0.7, 24, pale, w * 0.7)
	else:
		draw_arc(Vector2.ZERO, r, PI - 0.9, PI + 0.9, 24, gold, w)
		draw_arc(Vector2.ZERO, r * 0.8, PI - 0.7, PI + 0.7, 24, pale, w * 0.7)
	# Ground shockwave ring.
	draw_arc(Vector2(0, 46), 20.0 + k * 130.0, PI, TAU, 28, Color(1, 0.9, 0.5, 0.6 * a), 4.0)
	# Speed lines converging forward.
	for i in 3:
		var y := -34.0 + float(i) * 30.0
		var x0 := dir * lerpf(-10.0, 60.0, k)
		var x1 := dir * (60.0 + k * 120.0)
		draw_line(Vector2(x0, y), Vector2(x1, y), white, 3.0)
