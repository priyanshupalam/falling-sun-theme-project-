class_name PlaceholderArt
extends RefCounted
## Generates placeholder textures + SpriteFrames at runtime.
##
## WHY: The game ships with placeholder art so it runs WITHOUT any
## imported PNGs. Every character uses AnimatedSprite2D with animation
## names: idle, run, jump, fall, attack, hurt, death.
##
## HOW TO REPLACE WITH YOUR OWN ART:
## 1. Drop your sprite-sheet PNGs into res://assets/player/ (etc).
## 2. Open the matching scene (e.g. scenes/Player.tscn).
## 3. Select the AnimatedSprite2D, open SpriteFrames, replace each
##    animation's frames with your textures. Keep the SAME animation
##    names — no code changes needed.
## 4. Delete the `PlaceholderArt.setup_*()` call in that character's
##    _ready() (one line), since real frames are now in the .tscn.

static var _cache: Dictionary = {}

static func _make_frame(size: Vector2i, base: Color, accent: Color, variant: int) -> ImageTexture:
	var img := Image.create(size.x, size.y, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	# Body: rounded-ish rect
	var bx0 := int(size.x * 0.28)
	var bx1 := int(size.x * 0.72)
	var by0 := int(size.y * 0.18) + variant * 2
	var by1 := int(size.y * 0.92)
	for y in range(by0, by1):
		for x in range(bx0, bx1):
			var edge := x == bx0 or x == bx1 - 1 or y == by0 or y == by1 - 1
			img.set_pixel(x, y, accent if edge else base)
	# Eyes (face direction is +x; flip handled by node flip_h)
	var ey := by0 + int(size.y * 0.18)
	var ex := int(size.x * 0.52) + variant
	if ex + 1 < size.x and ey < size.y:
		img.set_pixel(ex, ey, Color.WHITE)
		img.set_pixel(ex + 1, ey, Color.BLACK)
	# Feet offset per variant (walk cycle feel)
	var fy := size.y - 1
	var fx := int(size.x * 0.35) + variant * 4
	if fx >= 0 and fx < size.x:
		img.set_pixel(fx, fy, accent)
		img.set_pixel(fx + 1 if fx + 1 < size.x else fx, fy, accent)
	return ImageTexture.create_from_image(img)

static func _frames_for(base: Color, accent: Color, size: Vector2i, counts: Dictionary) -> SpriteFrames:
	var key := "%s_%s_%d" % [base.to_html(), accent.to_html(), size.x]
	if _cache.has(key):
		return _cache[key]
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	for anim in counts.keys():
		if not sf.has_animation(anim):
			sf.add_animation(anim)
		sf.set_animation_loop(anim, anim in ["idle", "run", "walk"])
		sf.set_animation_speed(anim, 8.0 if anim in ["run", "attack"] else 5.0)
		var n: int = int(counts[anim])
		for i in range(n):
			var v := i % 3
			# Attack frames flash white-ish; special glows gold; hurt goes red-ish.
			var b := base
			if anim == "attack":
				b = base.lerp(Color.WHITE, 0.25 + 0.2 * float(i))
			elif anim == "special":
				b = base.lerp(Color(1.0, 0.85, 0.3), 0.3 + 0.25 * float(i))
			elif anim == "hurt":
				b = Color(1.0, 0.35, 0.35)
			elif anim == "death":
				b = base.lerp(Color(0.1, 0.1, 0.1), 0.25 * float(i))
			sf.add_frame(anim, _make_frame(size, b, accent, v))
	_cache[key] = sf
	return sf

static func _apply(sprite: AnimatedSprite2D, base: Color, accent: Color, size: Vector2i, counts: Dictionary) -> void:
	# If the .tscn already has real frames (artist replaced them), keep them.
	if sprite.sprite_frames != null and sprite.sprite_frames.has_animation("idle"):
		var f: int = sprite.sprite_frames.get_frame_count("idle")
		if f > 0:
			var tex = sprite.sprite_frames.get_frame_texture("idle", 0)
			# Heuristic: placeholder frames are tiny (<=64px). Real art is bigger.
			if tex != null and tex.get_width() > 70:
				return
	sprite.sprite_frames = _frames_for(base, accent, size, counts)
	sprite.play("idle")

static func setup_player(sprite: AnimatedSprite2D) -> void:
	# Prince: royal blue + gold trim, cape feel.
	_apply(sprite,
		Color(0.2, 0.35, 0.95), Color(0.95, 0.8, 0.25),
		Vector2i(48, 56),
		{"idle": 2, "run": 4, "jump": 1, "fall": 1, "attack": 3, "hurt": 1, "death": 3, "special": 3})

static func setup_zombie(sprite: AnimatedSprite2D, tint: Color) -> void:
	var dark := tint.darkened(0.55)
	_apply(sprite, tint, dark, Vector2i(48, 56),
		{"idle": 2, "walk": 4, "attack": 2, "hurt": 1, "death": 3})

static func setup_scientist(sprite: AnimatedSprite2D) -> void:
	_apply(sprite,
		Color(0.9, 0.9, 0.95), Color(0.2, 0.7, 0.3),
		Vector2i(64, 76),
		{"idle": 2, "walk": 4, "attack_throw": 3, "attack_slam": 3,
			"summon": 3, "hurt": 1, "death": 4, "attack": 3})

static func solid_texture(color: Color, size: Vector2i = Vector2i(16, 16)) -> ImageTexture:
	var img := Image.create(size.x, size.y, false, Image.FORMAT_RGBA8)
	img.fill(color)
	return ImageTexture.create_from_image(img)

static func circle_texture(color: Color, diameter: int = 48) -> ImageTexture:
	var img := Image.create(diameter, diameter, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var r := float(diameter) * 0.5
	for y in range(diameter):
		for x in range(diameter):
			var d := Vector2(x - r, y - r).length()
			if d <= r:
				var a := 1.0
				if d > r - 3.0:
					a = 0.9
				img.set_pixel(x, y, Color(color.r, color.g, color.b, a * color.a))
	return ImageTexture.create_from_image(img)

static func item_texture(kind: String) -> ImageTexture:
	match kind:
		"medkit":
			return _make_item(Color(0.95, 0.95, 0.95), Color(0.9, 0.15, 0.2))
		"heart":
			return _make_item(Color(0.95, 0.25, 0.35), Color(0.6, 0.05, 0.15))
		"poison":
			return _make_item(Color(0.3, 0.85, 0.2), Color(0.1, 0.4, 0.1))
		"flask":
			return _make_item(Color(0.6, 0.9, 0.2), Color(0.3, 0.5, 0.1))
	return _make_item(Color.WHITE, Color.GRAY)

static func _make_item(base: Color, edge: Color) -> ImageTexture:
	var s := 28
	var img := Image.create(s, s, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for y in range(5, s - 5):
		for x in range(5, s - 5):
			var is_edge := x < 8 or x >= s - 8 or y < 8 or y >= s - 8
			img.set_pixel(x, y, edge if is_edge else base)
	# cross / shine
	for i in range(10, 18):
		img.set_pixel(i, 13, Color.WHITE)
		img.set_pixel(i, 14, Color.WHITE)
	return ImageTexture.create_from_image(img)
