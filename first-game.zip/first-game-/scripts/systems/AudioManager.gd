extends Node
## Global audio hooks. All gameplay code calls AudioManager.play_sfx().
##
## HOW TO REPLACE SOUNDS:
## 1. Drop .wav/.ogg files into res://assets/audio/sfx/ with these names:
##    swing, hit, enemy_die, player_hurt, pickup, potion_throw, poison,
##    boss_hit, boss_die, boss_attack, ui_click, victory, gameover, jump,
##    charge, royal_slash
##    and res://assets/audio/music/ with: menu, game, boss
## 2. Nothing else to change — missing files fall back to a tiny
##    procedural beep (synthesized live with AudioStreamGenerator,
##    so the game never needs audio files and never crashes without them).

var _players: Array[AudioStreamPlayer] = []
var _generators: Array[AudioStreamGenerator] = []
var _music_player: AudioStreamPlayer
var _cache: Dictionary = {}
var _next_pool: int = 0
const POOL_SIZE: int = 8
const MIX_RATE: int = 22050
const SFX_DIR: String = "res://assets/audio/sfx/"
const MUSIC_DIR: String = "res://assets/audio/music/"

# Procedural fallback beeps: sound name -> [frequency, duration, volume].
const BEEPS: Dictionary = {
	"swing": [700.0, 0.08, 0.25],
	"hit": [220.0, 0.12, 0.4],
	"enemy_die": [160.0, 0.25, 0.4],
	"player_hurt": [110.0, 0.3, 0.5],
	"pickup": [880.0, 0.12, 0.35],
	"potion_throw": [500.0, 0.15, 0.3],
	"poison": [300.0, 0.3, 0.35],
	"boss_hit": [180.0, 0.15, 0.45],
	"boss_die": [90.0, 0.6, 0.5],
	"boss_attack": [140.0, 0.25, 0.45],
	"ui_click": [660.0, 0.06, 0.25],
	"victory": [523.0, 0.5, 0.4],
	"gameover": [130.0, 0.6, 0.45],
	"jump": [440.0, 0.08, 0.2],
	"charge": [320.0, 0.3, 0.3],
	"royal_slash": [180.0, 0.4, 0.5],
}

var _enabled: bool = true
var _music_enabled: bool = true

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in POOL_SIZE:
		var gen := AudioStreamGenerator.new()
		gen.mix_rate = MIX_RATE
		gen.buffer_length = 1.0
		var p := AudioStreamPlayer.new()
		p.bus = "Master"
		p.stream = gen
		add_child(p)
		_players.append(p)
		_generators.append(gen)
	_music_player = AudioStreamPlayer.new()
	_music_player.bus = "Master"
	add_child(_music_player)

func set_enabled(v: bool) -> void:
	_enabled = v

func set_music_enabled(v: bool) -> void:
	_music_enabled = v
	if not v:
		stop_music()

func _load_stream(path: String) -> AudioStream:
	if _cache.has(path):
		return _cache[path]
	if ResourceLoader.exists(path):
		var s := load(path) as AudioStream
		if s != null:
			_cache[path] = s
			return s
	return null

func _free_player_index() -> int:
	for i in _players.size():
		if not _players[i].playing:
			return i
	# All busy: steal round-robin so rapid sounds don't pile onto one voice.
	_next_pool = (_next_pool + 1) % POOL_SIZE
	return _next_pool

func _play_beep(p: AudioStreamPlayer, gen: AudioStreamGenerator, sfx_name: String, pitch: float) -> void:
	# Synthesize the beep live into the player's generator stream.
	p.stream = gen
	p.pitch_scale = 1.0
	p.volume_db = 0.0
	p.play()
	var pb := p.get_stream_playback() as AudioStreamGeneratorPlayback
	if pb == null:
		return
	pb.clear_buffer()
	var params: Array = BEEPS.get(sfx_name, [440.0, 0.1, 0.3]) as Array
	var freq: float = float(params[0]) * pitch * randf_range(0.95, 1.05)
	var dur: float = float(params[1])
	var vol: float = float(params[2])
	var count := int(MIX_RATE * dur)
	for i in count:
		var t := float(i) / MIX_RATE
		var env := 1.0 - float(i) / float(maxi(count, 1))
		var s := sin(TAU * freq * t) * env * vol
		pb.push_frame(Vector2(s, s))

func play_sfx(sfx_name: String, pitch: float = 1.0) -> void:
	if not _enabled:
		return
	var stream: AudioStream = null
	for ext in [".wav", ".ogg"]:
		var path: String = SFX_DIR + sfx_name + ext
		if ResourceLoader.exists(path):
			stream = _load_stream(path)
			if stream != null:
				break
	var idx := _free_player_index()
	var p: AudioStreamPlayer = _players[idx]
	if stream != null:
		p.stream = stream
		p.pitch_scale = pitch * randf_range(0.95, 1.05)
		p.play()
		return
	_play_beep(p, _generators[idx], sfx_name, pitch)

func play_music(track: String) -> void:
	if not _music_enabled:
		return
	var stream: AudioStream = null
	for ext in [".wav", ".ogg"]:
		var path: String = MUSIC_DIR + track + ext
		if ResourceLoader.exists(path):
			stream = _load_stream(path)
			break
	if stream == null:
		return  # No placeholder music; silence is fine.
	if _music_player.stream == stream and _music_player.playing:
		return
	_music_player.stream = stream
	_music_player.volume_db = -10.0
	_music_player.play()

func stop_music() -> void:
	_music_player.stop()
