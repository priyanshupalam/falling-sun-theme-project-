extends Node
## LevelManager: high-level wave state ONLY.
## No combat, AI, item, or boss logic here — it just spawns waves,
## counts survivors, and reports progress via signals.
## Level.gd owns the world; Main.gd owns the flow; this owns waves.

signal wave_started(wave_num: int, wave_total: int)
signal wave_cleared(wave_num: int, wave_total: int)
signal enemy_killed(pos: Vector2, zombie_type: String)
signal boss_spawned(boss: Node2D)
signal boss_defeated
signal level_completed(level_index: int)

const ZombieScene: PackedScene = preload("res://scenes/Zombie.tscn")
const BossScene: PackedScene = preload("res://scenes/Scientist.tscn")

var level_index: int = 0
var level_cfg: Dictionary = {}
var waves: Array = []
var current_wave: int = -1  # 0-based active wave; -1 = none active
var pending: Array[String] = []
var alive: int = 0
var spawn_interval: float = 1.0
var running: bool = false

var enemy_container: Node2D = null
var spawn_positions: Array[Vector2] = []

var _spawn_t: float = 0.0
var _between_t: float = -1.0
var _next_index: int = 0
var _boss: Node2D = null
var _boss_dead: bool = false
var _spawn_flip: bool = false

func setup(p_index: int, p_container: Node2D, p_spawns: Array[Vector2]) -> void:
	level_index = p_index
	level_cfg = Balance.get_level(p_index)
	enemy_container = p_container
	spawn_positions = p_spawns
	waves = level_cfg.get("waves", [])
	spawn_interval = float(level_cfg.get("spawn_interval", 1.0))
	current_wave = -1
	pending.clear()
	alive = 0
	_boss = null
	_boss_dead = false
	_between_t = -1.0
	_next_index = 0

func start() -> void:
	running = true
	_between_t = 1.0
	_next_index = 0

func stop() -> void:
	running = false
	_between_t = -1.0

func wave_total() -> int:
	return waves.size()

func _process(delta: float) -> void:
	if not running:
		return
	# Intermission timer -> begin next wave or spawn boss.
	if _between_t > 0.0:
		_between_t -= delta
		if _between_t <= 0.0:
			if Balance.is_boss_level(level_index):
				if _boss == null:
					_spawn_boss()
			else:
				_begin_wave(_next_index)
		return
	# Trickle-spawn pending enemies.
	if not pending.is_empty():
		_spawn_t -= delta
		if _spawn_t <= 0.0:
			_spawn_t = spawn_interval
			_spawn_one(pending.pop_back())
		return
	# Normal levels: wave cleared when active wave has no pending + none alive.
	if not Balance.is_boss_level(level_index):
		if current_wave >= 0 and alive <= 0:
			_cleared_wave(current_wave)
		return
	# Boss level: done when boss dead and minions cleared.
	if _boss_dead and alive <= 0:
		running = false
		emit_signal("level_completed", level_index)

func _begin_wave(idx: int) -> void:
	if idx < 0 or idx >= waves.size():
		running = false
		emit_signal("level_completed", level_index)
		return
	current_wave = idx
	pending.clear()
	var w: Dictionary = waves[idx]
	for ztype in w.keys():
		for i in int(w[ztype]):
			pending.append(String(ztype))
	pending.shuffle()
	_spawn_t = 0.2
	emit_signal("wave_started", idx + 1, waves.size())

func _cleared_wave(idx: int) -> void:
	current_wave = -1  # prevent re-firing
	emit_signal("wave_cleared", idx + 1, waves.size())
	if idx + 1 >= waves.size():
		running = false
		emit_signal("level_completed", level_index)
	else:
		_next_index = idx + 1
		_between_t = 2.4

func _pick_spawn_pos() -> Vector2:
	if spawn_positions.is_empty():
		return Vector2(randf_range(-600.0, 600.0), -40.0)
	_spawn_flip = not _spawn_flip
	var base: Vector2 = spawn_positions[0 if _spawn_flip else 1 % spawn_positions.size()]
	return base + Vector2(randf_range(-40.0, 40.0), randf_range(-20.0, 20.0))

func _spawn_one(ztype: String) -> void:
	if enemy_container == null:
		return
	var z = ZombieScene.instantiate()
	enemy_container.add_child(z)
	z.global_position = _pick_spawn_pos()
	z.call("apply_type", ztype)
	z.connect("died", _on_enemy_died)
	alive += 1

func spawn_minion(ztype: String, pos: Vector2, cap: int = 6) -> void:
	# Called for boss summons (and future events). Respects a cap.
	if not running or enemy_container == null:
		return
	if alive >= cap:
		return
	var z = ZombieScene.instantiate()
	enemy_container.add_child(z)
	z.global_position = pos
	z.call("apply_type", ztype)
	z.connect("died", _on_enemy_died)
	alive += 1

func _on_enemy_died(zombie: Node2D, ztype: String) -> void:
	alive = maxi(0, alive - 1)
	var pos := zombie.global_position if is_instance_valid(zombie) else Vector2.ZERO
	emit_signal("enemy_killed", pos, ztype)

func _spawn_boss() -> void:
	if enemy_container == null:
		return
	_boss = BossScene.instantiate()
	enemy_container.add_child(_boss)
	_boss.global_position = Vector2(350.0, -60.0)
	_boss.connect("died", _on_boss_died)
	_boss.connect("summon_requested", _on_boss_summon)
	if _boss.has_signal("health_changed"):
		# Level.gd re-emits to HUD; also forward here for convenience.
		pass
	alive = 0
	emit_signal("boss_spawned", _boss)

func _on_boss_died() -> void:
	_boss_dead = true
	emit_signal("boss_defeated")
	# level_completed fires from _process once minions are also cleared.

func _on_boss_summon(ztype: String, pos: Vector2) -> void:
	var cap := int(Balance.BOSS.get("max_minions", 3)) + 1
	spawn_minion(ztype, pos, cap)
