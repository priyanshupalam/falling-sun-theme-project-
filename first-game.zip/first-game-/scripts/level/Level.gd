extends Node2D
## Level: builds the arena, owns player/enemies/items/effects,
## rolls item drops, spawns poison bottles, does screenshake.
## Wave state lives in $WaveManager (LevelManager). Flow lives in Main.
## Signals below are the ONLY coupling to Main/UI.

signal wave_started(wave_num: int, wave_total: int)
signal wave_cleared(wave_num: int, wave_total: int)
signal boss_spawned(boss: Node2D)
signal boss_defeated
signal level_completed(level_index: int)
signal player_died

const PlayerScene: PackedScene = preload("res://scenes/Player.tscn")
const PickupScene: PackedScene = preload("res://scenes/items/ItemPickup.tscn")
const BottleScene: PackedScene = preload("res://scenes/effects/PoisonBottle.tscn")

const LEVEL_TINTS: Array[Color] = [
	Color(0.12, 0.16, 0.28),  # 1 night village
	Color(0.08, 0.20, 0.14),  # 2 forest
	Color(0.22, 0.14, 0.12),  # 3 ruins
	Color(0.16, 0.10, 0.22),  # 4 graveyard
	Color(0.20, 0.10, 0.16),  # 5 lab
]
const GROUND_TINTS: Array[Color] = [
	Color(0.25, 0.32, 0.25),
	Color(0.18, 0.32, 0.22),
	Color(0.35, 0.28, 0.22),
	Color(0.28, 0.25, 0.32),
	Color(0.32, 0.22, 0.28),
]

var level_index: int = 0
var player = null
var manager: Node = null
var enemy_root: Node2D = null
var item_root: Node2D = null
var fx_root: Node2D = null
var spawn_points: Array[Vector2] = []

var _shake: float = 0.0

func setup(p_index: int) -> void:
	level_index = p_index
	_build_environment()
	_build_containers()
	_spawn_player()
	_start_waves()

func get_player():
	return player

func get_manager() -> Node:
	return manager

func _build_environment() -> void:
	var tint: Color = LEVEL_TINTS[level_index % LEVEL_TINTS.size()]
	var gtint: Color = GROUND_TINTS[level_index % GROUND_TINTS.size()]
	# Sky/background: replaceable art hook — drop
	# res://assets/backgrounds/level_1.png ... level_5.png to override.
	var bg := Sprite2D.new()
	bg.name = "Background"
	bg.centered = true
	bg.position = Vector2(0, -160)
	var art_path := "res://assets/backgrounds/level_%d.png" % (level_index + 1)
	if ResourceLoader.exists(art_path):
		bg.texture = load(art_path)
		bg.scale = Vector2(4, 3)
	else:
		bg.texture = PlaceholderArt.solid_texture(tint, Vector2i(32, 32))
		bg.scale = Vector2(120, 40)
	bg.z_index = -100
	add_child(bg)
	# Simple moon/torch dots for depth (cheap parallax feel via fixed pos).
	for i in 12:
		var star := Sprite2D.new()
		star.texture = PlaceholderArt.circle_texture(Color(1, 1, 1, 0.5), 6)
		star.position = Vector2(randf_range(-850, 850), randf_range(-420, -80))
		star.z_index = -99
		add_child(star)
	# Ground.
	var ground := StaticBody2D.new()
	ground.name = "Ground"
	ground.position = Vector2(0, 110)
	var col := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = Vector2(1900, 60)
	col.shape = rect
	ground.add_child(col)
	add_child(ground)
	var gfx := Sprite2D.new()
	gfx.texture = PlaceholderArt.solid_texture(gtint, Vector2i(32, 32))
	gfx.scale = Vector2(60, 2.2)
	gfx.position = Vector2(0, 82)
	gfx.z_index = -50
	add_child(gfx)
	# Grass strip.
	var strip := Sprite2D.new()
	strip.texture = PlaceholderArt.solid_texture(gtint.lightened(0.35), Vector2i(32, 8))
	strip.scale = Vector2(60, 1.0)
	strip.position = Vector2(0, 78)
	strip.z_index = -49
	add_child(strip)
	# Walls keep everyone in the arena.
	for x in [-880.0, 880.0]:
		var wall := StaticBody2D.new()
		wall.position = Vector2(x, -100)
		var wc := CollisionShape2D.new()
		var wr := RectangleShape2D.new()
		wr.size = Vector2(40, 700)
		wc.shape = wr
		wall.add_child(wc)
		add_child(wall)
	spawn_points = [Vector2(-720, -40), Vector2(720, -40)]

func _build_containers() -> void:
	enemy_root = Node2D.new()
	enemy_root.name = "Enemies"
	add_child(enemy_root)
	item_root = Node2D.new()
	item_root.name = "Items"
	add_child(item_root)
	fx_root = Node2D.new()
	fx_root.name = "Effects"
	add_child(fx_root)
	manager = preload("res://scripts/level/LevelManager.gd").new()
	manager.name = "WaveManager"
	add_child(manager)

func _spawn_player() -> void:
	player = PlayerScene.instantiate()
	add_child(player)
	player.position = Vector2(0, -40)
	# Camera stays inside the arena.
	var cam = player.get("camera")
	if cam != null:
		cam.limit_left = -860
		cam.limit_right = 860
		cam.limit_top = -500
		cam.limit_bottom = 200
	player.connect("died", _on_player_died)
	player.connect("throw_requested", _on_throw_requested)
	player.connect("attack_started", _on_player_attacked)
	player.connect("special_shock", _on_special_shock)

func _start_waves() -> void:
	manager.call("setup", level_index, enemy_root, spawn_points)
	manager.connect("wave_started", _on_wave_started)
	manager.connect("wave_cleared", _on_wave_cleared)
	manager.connect("enemy_killed", _on_enemy_killed)
	manager.connect("boss_spawned", _on_boss_spawned)
	manager.connect("boss_defeated", _on_boss_defeated)
	manager.connect("level_completed", _on_level_completed)
	manager.call("start")

func stop() -> void:
	if manager != null and manager.has_method("stop"):
		manager.call("stop")

# ---------- SIGNAL FORWARDS ----------
func _on_wave_started(w: int, t: int) -> void:
	emit_signal("wave_started", w, t)

func _on_wave_cleared(w: int, t: int) -> void:
	AudioManager.play_sfx("victory", 0.7)
	emit_signal("wave_cleared", w, t)

func _on_level_completed(idx: int) -> void:
	emit_signal("level_completed", idx)

func _on_player_died() -> void:
	stop()
	emit_signal("player_died")

# ---------- COMBAT FX ----------
func _on_player_attacked(_facing: int) -> void:
	if player != null and player.has_method("get"):
		pass
	# Hit sparks appear when damage lands (see _on_enemy_killed flash);
	# the slash visual itself is spawned by Player.

func _on_throw_requested(origin: Vector2, dir: int) -> void:
	var b = BottleScene.instantiate()
	fx_root.add_child(b)
	b.call("launch", origin, dir)

func _on_enemy_killed(pos: Vector2, _ztype: String) -> void:
	# Hit flash at kill position (lives in fx layer so it survives).
	var HitSparkScript := load("res://scripts/effects/HitSpark.gd")
	HitSparkScript.spawn(fx_root, pos + Vector2(0, -30), Color(1, 0.85, 0.4), 1.0)
	_roll_drop(pos)

func _roll_drop(pos: Vector2) -> void:
	var r := randf()
	var kind := ""
	if r < float(Balance.DROPS.get("poison_chance", 0.14)):
		kind = "poison"
	elif r < float(Balance.DROPS.get("poison_chance", 0.14)) + float(Balance.DROPS.get("medkit_chance", 0.10)):
		kind = "medkit"
	elif r < float(Balance.DROPS.get("poison_chance", 0.14)) + float(Balance.DROPS.get("medkit_chance", 0.10)) + float(Balance.DROPS.get("heart_chance", 0.05)):
		kind = "heart"
	if kind == "":
		return
	var p = PickupScene.instantiate()
	item_root.add_child(p)
	p.global_position = pos + Vector2(randf_range(-10, 10), -40)
	p.call("setup", kind)

# ---------- BOSS ----------
func _on_boss_spawned(boss: Node2D) -> void:
	emit_signal("boss_spawned", boss)
	if boss.has_signal("slammed"):
		boss.connect("slammed", _on_boss_slam)
	if boss.has_signal("poison_drop_requested"):
		boss.connect("poison_drop_requested", _on_boss_poison_drop)

func _on_boss_poison_drop(pos: Vector2) -> void:
	# Reuses the normal pickup pipeline: same scene, same inventory,
	# same E-to-throw bottle and cloud. Only extras: a despawn lifetime
	# (the Scientist enforces the live-bottle cap before requesting).
	var p = PickupScene.instantiate()
	item_root.add_child(p)
	p.global_position = Vector2(clampf(pos.x, -820.0, 820.0), pos.y)
	p.call("setup", "poison")
	p.set("lifetime", float(Balance.BOSS_POISON_LIFETIME))
	AudioManager.play_sfx("potion_throw", 0.7)

func _on_boss_defeated() -> void:
	AudioManager.play_sfx("victory")
	_shake = 14.0
	emit_signal("boss_defeated")

func _on_boss_slam(pos: Vector2, radius: float) -> void:
	_shake = 12.0
	AudioManager.play_sfx("boss_attack")
	# Shockwave ring (placeholder; replace with your particle scene).
	var ring := Node2D.new()
	ring.global_position = pos + Vector2(0, 40)
	fx_root.add_child(ring)
	# Draw via HitSpark with big size + red tint.
	var HitSparkScript := load("res://scripts/effects/HitSpark.gd")
	HitSparkScript.spawn(fx_root, pos + Vector2(0, 20), Color(1, 0.3, 0.2), radius / 60.0)

func _on_special_shock(pos: Vector2, radius: float) -> void:
	# Royal Slash impact feel: small shake + gold ring (tuned in Balance).
	add_shake(Balance.ROYAL_SHAKE)
	var HitSparkScript := load("res://scripts/effects/HitSpark.gd")
	HitSparkScript.spawn(fx_root, pos + Vector2(0, -20), Color(1, 0.85, 0.35), radius / 60.0)

# ---------- SCREENSHAKE ----------
func _process(delta: float) -> void:
	if _shake > 0.0 and player != null and is_instance_valid(player):
		_shake = maxf(0.0, _shake - 40.0 * delta)
		var cam = player.get("camera")
		if cam != null:
			cam.offset = Vector2(randf_range(-_shake, _shake), randf_range(-_shake, _shake))
			if _shake <= 0.0:
				cam.offset = Vector2.ZERO

func add_shake(amount: float) -> void:
	_shake = minf(20.0, _shake + amount)
