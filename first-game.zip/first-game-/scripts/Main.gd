extends Node
## Main: game flow + screens. The ONLY high-level flow script.
## LOOP: MENU -> LEVEL 1 -> waves -> LEVEL COMPLETE -> ... -> BOSS -> VICTORY.
## Combat/AI/items live in their own scripts; this just loads levels,
## wires HUD signals, shows banners/screens, and fades between levels.

const LevelScene: PackedScene = preload("res://scenes/Level.tscn")

enum Flow { MENU, PLAYING, GAMEOVER, VICTORY }

var flow: int = Flow.MENU
var level = null
var _busy: bool = false
var _enraged_announced: bool = false

@onready var world_root: Node2D = $WorldRoot
@onready var ui_root: CanvasLayer = $UIRoot

var hud: Control = null
var menu_screen: Control = null
var over_screen: Control = null
var win_screen: Control = null
var settings_panel: Control = null
var transition_rect: ColorRect = null

func _ready() -> void:
	_ensure_input()
	hud = preload("res://scripts/ui/HUD.gd").new()
	hud.name = "HUD"
	ui_root.add_child(hud)
	hud.visible = false
	_build_menu()
	_build_gameover()
	_build_victory()
	_build_transition()  # last so the fade draws above everything
	Game.connect("progress_changed", _on_progress)
	AudioManager.play_music("menu")
	_show_menu()

# ---------- INPUT FALLBACK ----------
# project.godot already defines these; this guarantees they exist
# even if the input map was ever reset in the editor.
func _ensure_input() -> void:
	_add_key_action("move_left", [KEY_A, KEY_LEFT])
	_add_key_action("move_right", [KEY_D, KEY_RIGHT])
	_add_key_action("jump", [KEY_SPACE, KEY_W, KEY_UP])
	_add_key_action("attack", [KEY_J])
	_add_key_action("use_item", [KEY_E, KEY_K])
	_add_key_action("special_attack", [KEY_Q])
	if not InputMap.has_action("attack"):
		InputMap.add_action("attack")
	var has_mouse := false
	for e in InputMap.action_get_events("attack"):
		if e is InputEventMouseButton:
			has_mouse = true
	if not has_mouse:
		var mb := InputEventMouseButton.new()
		mb.button_index = MOUSE_BUTTON_LEFT
		InputMap.action_add_event("attack", mb)

func _add_key_action(action: String, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for k in keys:
		var exists := false
		for e in InputMap.action_get_events(action):
			if e is InputEventKey and (e as InputEventKey).physical_keycode == k:
				exists = true
		if not exists:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(action, ev)

# ---------- UI BUILD ----------
func _screen_base(name: String) -> CenterContainer:
	var c := CenterContainer.new()
	c.name = name
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui_root.add_child(c)
	return c

func _title_label(text: String, size: int, color: Color = Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
	l.add_theme_constant_override("shadow_offset_x", 3)
	l.add_theme_constant_override("shadow_offset_y", 3)
	return l

func _menu_button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(280, 52)
	b.add_theme_font_size_override("font_size", 24)
	b.pressed.connect(func() -> void: AudioManager.play_sfx("ui_click"))
	return b

func _build_transition() -> void:
	transition_rect = ColorRect.new()
	transition_rect.name = "Transition"
	transition_rect.color = Color(0, 0, 0, 0)
	transition_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	transition_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.add_child(transition_rect)

func _build_menu() -> void:
	menu_screen = _screen_base("MainMenu")
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	menu_screen.add_child(v)
	v.add_child(_title_label("PRINCE vs ZOMBIES", 64, Color(1, 0.85, 0.4)))
	v.add_child(_title_label("A tiny kingdom. A sharp sword. Too many zombies.", 20, Color(0.85, 0.85, 0.9)))
	var play := _menu_button("▶  PLAY")
	play.pressed.connect(_on_play_pressed)
	v.add_child(play)
	# Re-parent trick: keep buttons centered.
	var settings := _menu_button("⚙  SETTINGS")
	settings.pressed.connect(_on_settings_pressed)
	v.add_child(settings)
	var quit := _menu_button("✕  QUIT")
	quit.pressed.connect(_on_quit_pressed)
	v.add_child(quit)
	v.add_child(_title_label("Move A/D · Jump Space · Attack J/Click · Item E · Royal Slash Q", 16, Color(0.7, 0.7, 0.75)))
	# Center buttons: wrap each in CenterContainer via alignment.
	for child in v.get_children():
		if child is Button:
			child.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	settings_panel = _settings_box()
	settings_panel.visible = false
	v.add_child(settings_panel)

func _settings_box() -> Control:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	var sfx := CheckButton.new()
	sfx.text = "Sound effects"
	sfx.button_pressed = true
	sfx.toggled.connect(func(on: bool) -> void: AudioManager.set_enabled(on))
	v.add_child(sfx)
	var mus := CheckButton.new()
	mus.text = "Music"
	mus.button_pressed = true
	mus.toggled.connect(func(on: bool) -> void:
		AudioManager.set_music_enabled(on)
		if on:
			AudioManager.play_music("menu"))
	v.add_child(mus)
	v.add_child(_title_label("Replace art in res://assets/ — no code changes needed.", 14, Color(0.7, 0.75, 0.7)))
	return v

func _build_gameover() -> void:
	over_screen = _screen_base("GameOver")
	over_screen.visible = false
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	over_screen.add_child(v)
	v.add_child(_title_label("YOU DIED", 72, Color(0.95, 0.25, 0.25)))
	v.add_child(_title_label("The zombies overrun the kingdom... this time.", 20))
	var retry := _menu_button("↻  RETRY LEVEL")
	retry.pressed.connect(_on_retry_pressed)
	v.add_child(retry)
	var menu := _menu_button("MAIN MENU")
	menu.pressed.connect(_show_menu)
	v.add_child(menu)
	for child in v.get_children():
		if child is Button:
			child.size_flags_horizontal = Control.SIZE_SHRINK_CENTER

func _build_victory() -> void:
	win_screen = _screen_base("Victory")
	win_screen.visible = false
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	win_screen.add_child(v)
	v.add_child(_title_label("THE SCIENTIST HAS BEEN DEFEATED", 40, Color(0.5, 1, 0.55)))
	v.add_child(_title_label("THE KINGDOM IS SAFE", 30, Color(1, 0.9, 0.5)))
	v.add_child(_title_label("The prince raises his sword as dawn breaks over the lab.", 18))
	var again := _menu_button("▶  PLAY AGAIN")
	again.pressed.connect(_on_play_pressed)
	v.add_child(again)
	var menu := _menu_button("MAIN MENU")
	menu.pressed.connect(_show_menu)
	v.add_child(menu)
	for child in v.get_children():
		if child is Button:
			child.size_flags_horizontal = Control.SIZE_SHRINK_CENTER

# ---------- FLOW ----------
func _show_menu() -> void:
	flow = Flow.MENU
	_busy = false
	_clear_level()
	menu_screen.visible = true
	over_screen.visible = false
	win_screen.visible = false
	hud.visible = false
	AudioManager.play_music("menu")

func _on_play_pressed() -> void:
	if _busy:
		return
	Game.reset_run()
	menu_screen.visible = false
	over_screen.visible = false
	win_screen.visible = false
	hud.visible = true
	_load_level(Game.current_level)

func _on_retry_pressed() -> void:
	if _busy:
		return
	over_screen.visible = false
	win_screen.visible = false
	hud.visible = true
	# Retry current level fresh, keep earned max-health, refill HP.
	Game.player_health = Game.player_max_health
	_load_level(Game.current_level)

func _on_settings_pressed() -> void:
	settings_panel.visible = not settings_panel.visible

func _on_quit_pressed() -> void:
	get_tree().quit()

func _clear_level() -> void:
	if level != null and is_instance_valid(level):
		if level.has_method("stop"):
			level.stop()
		level.queue_free()
	level = null

func _fade(alpha: float, dur: float = 0.4) -> void:
	var tw := create_tween()
	tw.tween_property(transition_rect, "color:a", alpha, dur)

func _load_level(idx: int) -> void:
	if _busy:
		return
	_busy = true
	flow = Flow.PLAYING
	_fade(1.0, 0.35)
	await get_tree().create_timer(0.4).timeout
	_clear_level()
	await get_tree().process_frame
	Game.current_level = idx
	level = LevelScene.instantiate()
	world_root.add_child(level)
	_enraged_announced = false
	level.call("setup", idx)
	_wire_level()
	var cfg: Dictionary = Balance.get_level(idx)
	var lname: String = str(cfg.get("name", "Level %d" % (idx + 1)))
	if Balance.is_boss_level(idx):
		hud.set_wave(lname)
	else:
		hud.set_wave("%s — Get ready..." % lname)
	_refresh_hud()
	hud.clear_banner()
	hud.announce(lname, "Defeat all waves!" if not Balance.is_boss_level(idx) else "The Scientist awaits...", 1.8)
	AudioManager.play_music("boss" if Balance.is_boss_level(idx) else "game")
	_fade(0.0, 0.4)
	_busy = false

func _wire_level() -> void:
	level.connect("wave_started", _on_wave_started)
	level.connect("wave_cleared", _on_wave_cleared)
	level.connect("level_completed", _on_level_completed)
	level.connect("player_died", _on_player_died)
	level.connect("boss_spawned", _on_boss_spawned)
	level.connect("boss_defeated", _on_boss_defeated)
	var p = level.get_player()
	p.connect("health_changed", _on_hearts)
	p.connect("poisons_changed", _on_poisons)
	p.connect("special_changed", _on_special)
	_on_hearts(p.get("health"), p.get("max_health"))
	_on_poisons(Game.player_poisons)
	_on_special(0.0, Balance.ROYAL_COOLDOWN)

func _refresh_hud() -> void:
	var p = level.get_player() if level != null else null
	if p != null:
		_on_hearts(p.get("health"), p.get("max_health"))
	_on_poisons(Game.player_poisons)
	_on_progress()

func _on_progress() -> void:
	if hud != null:
		hud.set_score(Game.score)
		hud.set_poisons(Game.player_poisons)

func _on_hearts(hp: int, max_hp: int) -> void:
	hud.set_hearts(hp, max_hp)

func _on_poisons(n: int) -> void:
	hud.set_poisons(n)

func _on_special(remaining: float, total: float) -> void:
	hud.set_special(remaining, total)

func _on_wave_started(w: int, t: int) -> void:
	var cfg: Dictionary = Balance.get_level(Game.current_level)
	hud.set_wave("%s — WAVE %d/%d" % [str(cfg.get("name", "")), w, t])
	hud.announce("WAVE %d" % w, "Zombies incoming!", 1.4)
	AudioManager.play_sfx("ui_click", 0.7)

func _on_wave_cleared(w: int, t: int) -> void:
	hud.announce("WAVE COMPLETE", "%d/%d cleared" % [w, t], 1.6)

func _on_level_completed(idx: int) -> void:
	if flow != Flow.PLAYING or _busy:
		return
	_busy = true
	hud.announce("LEVEL COMPLETE", "The kingdom holds... for now.", 2.0)
	await get_tree().create_timer(2.3).timeout
	if flow != Flow.PLAYING:
		_busy = false
		return  # Player died during the transition; game-over takes precedence.
	if not Balance.is_boss_level(idx) and Game.advance_level():
		_busy = false
		_load_level(Game.current_level)
	else:
		_busy = false
		# Boss-level completion is handled by _on_boss_defeated instead.

func _on_boss_spawned(boss: Node2D) -> void:
	var bname: String = str(Balance.BOSS.get("name", "THE SCIENTIST"))
	hud.show_boss(bname, boss.get("hp"), boss.get("max_hp"))
	boss.connect("health_changed", _on_boss_hp)
	hud.announce(bname, "Phase 1 — watch the flasks!", 2.0)

func _on_boss_hp(hp: int, max_hp: int) -> void:
	hud.update_boss(hp, max_hp)
	# Phase callouts (once each).
	var frac := float(hp) / float(maxi(1, max_hp))
	if frac <= 0.33 and frac > 0.0 and not _enraged_announced:
		_enraged_announced = true
		hud.announce("THE SCIENTIST ENRAGED", "Dodge the slam!", 1.4)

func _on_boss_defeated() -> void:
	if flow != Flow.PLAYING:
		return
	hud.hide_boss()
	hud.announce("BOSS DEFEATED", "", 2.0)
	await get_tree().create_timer(2.4).timeout
	if flow != Flow.PLAYING:
		return  # Player died in the same moment; game-over takes precedence.
	_show_victory()

func _on_player_died() -> void:
	if flow != Flow.PLAYING:
		return
	flow = Flow.GAMEOVER
	await get_tree().create_timer(1.4).timeout
	hud.visible = false
	over_screen.visible = true

func _show_victory() -> void:
	flow = Flow.VICTORY
	AudioManager.play_sfx("victory")
	AudioManager.stop_music()
	hud.visible = false
	_clear_level()
	win_screen.visible = true
