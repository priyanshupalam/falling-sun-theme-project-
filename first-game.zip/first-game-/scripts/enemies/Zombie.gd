extends CharacterBody2D
## Reusable zombie enemy. One scene + one script for ALL zombie types.
## Configure via `zombie_type` (walker / runner / tank / ...).
## To add a new type: add stats in Balance.ZOMBIES — no code changes.
## Animations used: idle, walk, attack, hurt, death.

signal died(zombie: Node2D, zombie_type: String)

@export var zombie_type: String = "walker"

var max_hp: int = 3
var hp: int = 3
var damage: int = 1
var speed: float = 65.0
var attack_range: float = 44.0
var attack_cooldown: float = 1.2
var score_value: int = 10

var _cd: float = 0.0
var _hurt_t: float = 0.0
var _dead: bool = false
var _facing: int = -1
var _knockback: Vector2 = Vector2.ZERO
var _player = null

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
	add_to_group("enemies")
	apply_type(zombie_type)
	_find_player()

func apply_type(ztype: String) -> void:
	zombie_type = ztype
	var s: Dictionary = Balance.get_zombie(ztype)
	max_hp = int(s.get("hp", 3))
	hp = max_hp
	damage = int(s.get("damage", 1))
	speed = float(s.get("speed", 65.0))
	attack_range = float(s.get("attack_range", 44.0))
	attack_cooldown = float(s.get("attack_cooldown", 1.2))
	score_value = int(s.get("score", 10))
	var tint: Color = s.get("tint", Color.GREEN)
	var sc: float = float(s.get("scale_factor", 1.0))
	sprite.scale = Vector2(sc, sc)
	PlaceholderArt.setup_zombie(sprite, tint)

func _find_player() -> void:
	var players := get_tree().get_nodes_in_group("player")
	if not players.is_empty():
		_player = players[0]

func _physics_process(delta: float) -> void:
	if _dead:
		return
	_cd = maxf(0.0, _cd - delta)
	_hurt_t = maxf(0.0, _hurt_t - delta)
	if _player == null or not is_instance_valid(_player):
		_find_player()
		if _player == null:
			velocity.x = 0.0
			_apply_gravity(delta)
			move_and_slide()
			return
	# Gravity.
	_apply_gravity(delta)
	# Knockback decay.
	_knockback = _knockback.move_toward(Vector2.ZERO, 900.0 * delta)

	var to_player: Vector2 = _player.global_position - global_position
	var dist := absf(to_player.x)
	_facing = -1 if to_player.x < 0.0 else 1
	sprite.flip_h = _facing < 0

	if _hurt_t > 0.0:
		velocity.x = _knockback.x
		_play("hurt")
	else:
		if dist > attack_range:
			velocity.x = float(_facing) * speed + _knockback.x * 0.3
			_play("walk")
		else:
			velocity.x = _knockback.x * 0.2
			if _cd <= 0.0 and absf(to_player.y) < 70.0:
				_attack_player(to_player)
			else:
				_play("idle")
	move_and_slide()

func _apply_gravity(delta: float) -> void:
	if not is_on_floor():
		velocity.y += 1400.0 * delta
	else:
		velocity.y = minf(velocity.y, 5.0)

func _attack_player(to_player: Vector2) -> void:
	_cd = attack_cooldown
	_play("attack")
	AudioManager.play_sfx("hit", 0.7)
	if _player != null and _player.has_method("take_damage"):
		var dir := Vector2(signf(to_player.x), 0.0)
		# Small delay feel: damage lands slightly after wind-up via deferred? Keep instant for simplicity.
		_player.take_damage(damage, dir)

func take_damage(amount: int, from_dir: Vector2 = Vector2.ZERO, heavy: bool = false) -> void:
	if _dead:
		return
	hp -= amount
	# Royal Slash hits harder: longer stagger + bigger knockback.
	_hurt_t = 0.34 if heavy else 0.22
	var kb := 340.0 if heavy else 190.0
	_knockback = Vector2(signf(from_dir.x) * kb if from_dir.x != 0.0 else 0.0, -60.0)
	AudioManager.play_sfx("hit")
	_flash()
	if hp <= 0:
		_die()
	else:
		_play("hurt")

func _flash() -> void:
	sprite.modulate = Color(1.6, 1.6, 1.6)
	var tw := create_tween()
	tw.tween_property(sprite, "modulate", Color.WHITE, 0.15)

func _die() -> void:
	_dead = true
	_play("death")
	AudioManager.play_sfx("enemy_die")
	collision_layer = 0
	collision_mask = 0
	velocity = Vector2.ZERO
	Game.add_score(score_value)
	emit_signal("died", self, zombie_type)
	# Death anim then remove.
	await get_tree().create_timer(0.45).timeout
	queue_free()

func _play(anim: String) -> void:
	if sprite.sprite_frames != null and sprite.sprite_frames.has_animation(anim):
		if sprite.animation != anim or not sprite.is_playing():
			sprite.play(anim)

func is_alive() -> bool:
	return not _dead
