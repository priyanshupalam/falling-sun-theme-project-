extends Area2D
## Scientist's thrown flask. Damages the player on touch, then breaks.
## Also used as a template for any future ranged enemy.

var velocity: Vector2 = Vector2.ZERO
var damage: int = 1
var life: float = 4.0
var _spin: float = 0.0

func _ready() -> void:
	add_to_group("enemy_projectiles")
	collision_layer = 0
	collision_mask = 1
	var spr := Sprite2D.new()
	spr.texture = PlaceholderArt.item_texture("flask")
	spr.scale = Vector2(1.1, 1.1)
	add_child(spr)
	var shape := CollisionShape2D.new()
	var c := CircleShape2D.new()
	c.radius = 12.0
	shape.shape = c
	add_child(shape)
	body_entered.connect(_on_body)

func launch(from: Vector2, vel: Vector2, dmg: int = 1) -> void:
	global_position = from
	velocity = vel
	damage = dmg

func _physics_process(delta: float) -> void:
	life -= delta
	if life <= 0.0:
		queue_free()
		return
	velocity.y += 500.0 * delta
	position += velocity * delta
	_spin += 8.0 * delta
	rotation = _spin

func _on_body(body) -> void:
	if body.is_in_group("player") and body.has_method("take_damage"):
		var dir := velocity.normalized()
		body.call("take_damage", damage, dir)
		AudioManager.play_sfx("boss_attack", 0.8)
		queue_free()
	elif body is StaticBody2D:
		AudioManager.play_sfx("hit", 0.6)
		queue_free()
