extends CharacterBody2D
## Scientist boss — final level. Proper multi-phase state machine.
## Phases: 1 (>66%): throw + chase. 2 (>33%): + summons, faster.
##         3 (<33%): faster throws + aggressive slams.
## Attacks: flask throw (ranged), summon zombies, AoE slam.
## Also leaks poison bottles the Prince can pick up and throw back.
## To expand: add a state + attack function + hook into _pick_attack().

signal died
signal health_changed(hp: int, max_hp: int)
signal summon_requested(ztype: String, pos: Vector2)
signal slammed(pos: Vector2, radius: float)
signal poison_drop_requested(pos: Vector2)

enum S { IDLE, CHASE, THROW, SUMMON, SLAM, HURT, DEATH }

var max_hp: int = 60
var hp: int = 60
var speed: float = 95.0
var phase: int = 1

var _state: int = S.IDLE
var _state_t: float = 1.0
var _throw_cd: float = 2.0
var _summon_cd: float = 5.0
var _slam_cd: float = 3.0
var _facing: int = -1
var _dead: bool = false
var _player = null
var _did_throw: bool = false
var _did_summon: bool = false
var _did_slam: bool = false
# Boss poison drops: the Scientist leaks bottles the Prince can reuse.
var _poison_cd: float = 6.0

const ProjectileScene: PackedScene = preload("res://scenes/effects/BossProjectile.tscn")
# Drop zone: beside the boss, clamped inside the arena, on the ground
# (arena floor top sits near y=80; bottles bob just above it).
const DROP_ARENA_X: float = 800.0
const DROP_GROUND_Y: float = 40.0

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

func _ready() -> void:
	add_to_group("enemies")
	add_to_group("boss")
	var b: Dictionary = Balance.BOSS
	max_hp = int(b.get("hp", 60))
	hp = max_hp
	speed = float(b.get("speed", 95.0))
	PlaceholderArt.setup_scientist(sprite)
	_poison_cd = float(Balance.BOSS_POISON_FIRST_DELAY)
	_find_player()
	emit_signal("health_changed", hp, max_hp)

func _find_player() -> void:
	var ps := get_tree().get_nodes_in_group("player")
	if not ps.is_empty():
		_player = ps[0]

func _poison_bottle_count() -> int:
	return get_tree().get_nodes_in_group("poison_bottles").size()

func _maybe_drop_poison() -> void:
	# The Scientist decides WHEN and WHERE a bottle appears; Level.gd
	# handles spawning it (cap, lifetime, sound live there/then).
	if _dead or _player == null or not is_instance_valid(_player):
		return
	# Drop only at safe moments between attacks, never mid-attack.
	# The timer stays at 0 during attacks, so the bottle lands right after.
	if _state != S.IDLE and _state != S.CHASE:
		return
	if _poison_bottle_count() >= int(Balance.BOSS_POISON_MAX_DROPS):
		_poison_cd = 2.0  # Arena is stocked; check again soon.
		return
	var x := clampf(global_position.x + float(_facing) * 170.0, -DROP_ARENA_X, DROP_ARENA_X)
	emit_signal("poison_drop_requested", Vector2(x, DROP_GROUND_Y))
	_poison_cd = float(Balance.BOSS_POISON_DROP_COOLDOWN)

func _physics_process(delta: float) -> void:
	if _dead:
		return
	if _player == null or not is_instance_valid(_player):
		_find_player()
	_apply_gravity(delta)
	_throw_cd = maxf(0.0, _throw_cd - delta)
	_summon_cd = maxf(0.0, _summon_cd - delta)
	_slam_cd = maxf(0.0, _slam_cd - delta)
	_poison_cd = maxf(0.0, _poison_cd - delta)
	if _poison_cd <= 0.0:
		_maybe_drop_poison()
	_state_t -= delta
	_update_phase()
	if _player != null and is_instance_valid(_player):
		_facing = -1 if _player.global_position.x < global_position.x else 1
		sprite.flip_h = _facing < 0
	match _state:
		S.IDLE:
			velocity.x = move_toward(velocity.x, 0.0, 600.0 * delta)
			_play("idle")
			if _state_t <= 0.0:
				_pick_attack()
		S.CHASE:
			_chase(delta)
			if _state_t <= 0.0:
				_to_idle(0.3)
		S.THROW:
			velocity.x = move_toward(velocity.x, 0.0, 600.0 * delta)
			_play("attack_throw")
			if not _did_throw and _state_t <= 0.35:
				_did_throw = true
				_do_throw()
			if _state_t <= 0.0:
				_to_idle(0.4 if phase == 1 else 0.25)
		S.SUMMON:
			velocity.x = move_toward(velocity.x, 0.0, 600.0 * delta)
			_play("summon")
			if not _did_summon and _state_t <= 0.6:
				_did_summon = true
				_do_summon()
			if _state_t <= 0.0:
				_to_idle(0.5)
		S.SLAM:
			velocity.x = move_toward(velocity.x, 0.0, 800.0 * delta)
			_play("attack_slam")
			if not _did_slam and _state_t <= 0.5:
				_did_slam = true
				_do_slam()
			if _state_t <= 0.0:
				_to_idle(0.5)
		S.HURT:
			velocity.x = move_toward(velocity.x, 0.0, 800.0 * delta)
			_play("hurt")
			if _state_t <= 0.0:
				_to_idle(0.3)
		S.DEATH:
			pass
	move_and_slide()

func _apply_gravity(delta: float) -> void:
	if not is_on_floor():
		velocity.y += 1400.0 * delta

func _update_phase() -> void:
	var frac := float(hp) / float(maxi(1, max_hp))
	var new_phase := 1
	if frac <= 0.33:
		new_phase = 3
	elif frac <= 0.66:
		new_phase = 2
	if new_phase != phase:
		phase = new_phase
		# Phase shift burst: clear cooldowns a bit so fight escalates.
		_throw_cd = minf(_throw_cd, 0.8)
		AudioManager.play_sfx("boss_attack")

func _player_close(dist: float) -> bool:
	if _player == null:
		return false
	return absf(_player.global_position.x - global_position.x) < dist \
		and absf(_player.global_position.y - global_position.y) < 120.0

func _minion_count() -> int:
	var n := 0
	for e in get_tree().get_nodes_in_group("enemies"):
		if e != self and is_instance_valid(e) and e.has_method("is_alive"):
			if e.is_alive():
				n += 1
	return n

func _pick_attack() -> void:
	if _player == null:
		_to_idle(0.5)
		return
	var close := _player_close(170.0)
	var mid := _player_close(420.0)
	# Priority: punish close range with slam, keep pressure with throws.
	if close and _slam_cd <= 0.0:
		_start_slam()
		return
	if _throw_cd <= 0.0 and not mid:
		_start_throw()
		return
	if phase >= 2 and _summon_cd <= 0.0 and _minion_count() < int(Balance.BOSS.get("max_minions", 3)):
		_start_summon()
		return
	if _throw_cd <= 0.0:
		_start_throw()
		return
	if _slam_cd <= 0.0 and close:
		_start_slam()
		return
	# Default: chase to reposition (also dodges: backs off if crowded).
	_state = S.CHASE
	_state_t = 0.7 if phase == 1 else 0.5
	_play("walk")

func _chase(delta: float) -> void:
	_play("walk")
	if _player == null:
		return
	var dx: float = _player.global_position.x - global_position.x
	var want := 240.0  # ideal spacing
	var dir := 0.0
	if absf(dx) > want + 60.0:
		dir = signf(dx)
	elif absf(dx) < want - 90.0:
		dir = -signf(dx)  # back off — dodge feel
	else:
		dir = signf(dx) * 0.3  # strafe drift
	var spd := speed * (1.25 if phase == 2 else (1.55 if phase == 3 else 1.0))
	velocity.x = dir * spd

func _to_idle(t: float) -> void:
	_state = S.IDLE
	_state_t = t

func _start_throw() -> void:
	_state = S.THROW
	_state_t = 0.7
	_did_throw = false
	_throw_cd = float(Balance.BOSS.get("throw_cooldown", 2.2)) * (0.75 if phase == 2 else (0.55 if phase == 3 else 1.0))

func _start_summon() -> void:
	_state = S.SUMMON
	_state_t = 1.2
	_did_summon = false
	_summon_cd = float(Balance.BOSS.get("summon_cooldown", 9.0))

func _start_slam() -> void:
	_state = S.SLAM
	_state_t = 0.9
	_did_slam = false
	_slam_cd = float(Balance.BOSS.get("slam_cooldown", 5.0)) * (0.7 if phase == 3 else 1.0)

func _do_throw() -> void:
	if _player == null:
		return
	AudioManager.play_sfx("boss_attack")
	var count := 1 if phase == 1 else (2 if phase == 2 else 3)
	for i in count:
		var p = ProjectileScene.instantiate()
		get_parent().add_child(p)
		var from := global_position + Vector2(float(_facing) * 30.0, -50.0)
		var target: Vector2 = _player.global_position + Vector2(0, -30)
		var dir: Vector2 = (target - from).normalized()
		var spread := (float(i) - float(count - 1) * 0.5) * 0.18
		dir = dir.rotated(spread)
		var spd := 380.0 if phase < 3 else 460.0
		p.call("launch", from, dir * spd, int(Balance.BOSS.get("throw_damage", 1)))

func _do_summon() -> void:
	AudioManager.play_sfx("boss_attack", 0.7)
	var kinds := ["walker", "walker", "runner"] if phase == 2 else ["runner", "tank", "walker"]
	var n := 2 if phase == 2 else 3
	for i in n:
		var side := -1.0 if i % 2 == 0 else 1.0
		var pos := global_position + Vector2(side * (120.0 + 60.0 * float(i)), 0.0)
		emit_signal("summon_requested", kinds[i % kinds.size()], pos)

func _do_slam() -> void:
	AudioManager.play_sfx("boss_attack", 0.6)
	var radius := 190.0
	emit_signal("slammed", global_position, radius)
	# Direct damage (Level also adds screenshake + ring visual).
	if _player != null and _player.has_method("take_damage"):
		var d: Vector2 = _player.global_position - global_position
		if d.length() < radius and absf(d.y) < 130.0:
			_player.take_damage(int(Balance.BOSS.get("slam_damage", 2)), d.normalized())

func take_damage(amount: int, from_dir: Vector2 = Vector2.ZERO, heavy: bool = false) -> void:
	if _dead:
		return
	hp = maxi(0, hp - amount)
	AudioManager.play_sfx("boss_hit")
	emit_signal("health_changed", hp, max_hp)
	_flash()
	if hp <= 0:
		_die()
		return
	if heavy:
		# Royal Slash: guaranteed stagger that interrupts ANY current
		# attack (throw / summon / slam) for a brief opening.
		_state = S.HURT
		_state_t = 0.55
		velocity.x = signf(from_dir.x) * 150.0 if from_dir.x != 0.0 else 0.0
		return
	# Brief stagger on some normal hits.
	if randf() < 0.3:
		_state = S.HURT
		_state_t = 0.3
		velocity.x = signf(from_dir.x) * 120.0 if from_dir.x != 0.0 else 0.0

func _flash() -> void:
	sprite.modulate = Color(1.7, 1.7, 1.7)
	var tw := create_tween()
	tw.tween_property(sprite, "modulate", Color.WHITE, 0.15)

func _die() -> void:
	_dead = true
	_state = S.DEATH
	_play("death")
	velocity = Vector2.ZERO
	collision_layer = 0
	collision_mask = 0
	AudioManager.play_sfx("boss_die")
	emit_signal("died")

func _play(anim: String) -> void:
	# Map generic names to boss set (attack -> attack_throw).
	var a := anim
	if a == "attack":
		a = "attack_throw"
	if sprite.sprite_frames != null and sprite.sprite_frames.has_animation(a):
		if sprite.animation != a or not sprite.is_playing():
			sprite.play(a)

func is_alive() -> bool:
	return not _dead
