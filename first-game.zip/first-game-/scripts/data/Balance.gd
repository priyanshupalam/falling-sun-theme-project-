class_name Balance
extends RefCounted
## Single place to tune the whole game.
## Edit values here to change difficulty, waves, enemies, drops.
## No other script needs to be touched for balancing.
##
## HOW TO CUSTOMIZE:
## - Levels/waves: edit LEVELS below.
## - Zombie stats: edit ZOMBIES below.
## - Player stats: edit PLAYER_* consts.
## - Drops: edit DROPS.
## - Boss: edit BOSS.

# ---------- PLAYER ----------
const PLAYER_MAX_HEALTH: int = 5
const PLAYER_MOVE_SPEED: float = 280.0
const PLAYER_JUMP_VELOCITY: float = -560.0
const PLAYER_GRAVITY: float = 1500.0
const PLAYER_SWORD_DAMAGE: int = 1
const PLAYER_ATTACK_COOLDOWN: float = 0.42
const PLAYER_INVULN_TIME: float = 1.0
const PLAYER_START_POISONS: int = 1
const PLAYER_MAX_POISONS: int = 5

# ---------- SWORD ----------
const SWORD_RANGE: float = 78.0
const SWORD_ARC_HEIGHT: float = 56.0

# ---------- ROYAL SLASH (Q special attack) ----------
# Tune the special here: damage, cooldown, timings, hitbox size.
# ROYAL_DAMAGE: vs normal zombies. ROYAL_BOSS_DAMAGE: vs the Scientist.
const ROYAL_DAMAGE: int = 3
const ROYAL_BOSS_DAMAGE: int = 5
const ROYAL_COOLDOWN: float = 8.0
const ROYAL_CHARGE_TIME: float = 0.4
const ROYAL_STRIKE_TIME: float = 0.22
const ROYAL_RANGE: float = 175.0
const ROYAL_ARC_HEIGHT: float = 120.0
const ROYAL_SHAKE: float = 7.0

# ---------- POISON ----------
const POISON_BOTTLE_DAMAGE: int = 1
const POISON_CLOUD_DAMAGE: int = 2
const POISON_CLOUD_RADIUS: float = 130.0
const POISON_CLOUD_DURATION: float = 4.0
const POISON_CLOUD_TICK: float = 0.5

# ---------- ZOMBIE TYPES ----------
# Add new types here (e.g. "fast", "tank", "ranged") and they
# automatically work with the spawner + Level config.
# Fields: hp, damage, speed, attack_range, attack_cooldown, scale, tint
const ZOMBIES: Dictionary = {
	"walker": {
		"hp": 3, "damage": 1, "speed": 65.0,
		"attack_range": 44.0, "attack_cooldown": 1.2,
		"scale_factor": 1.0, "tint": Color(0.35, 0.85, 0.35),
		"score": 10,
	},
	"runner": {
		"hp": 2, "damage": 1, "speed": 150.0,
		"attack_range": 40.0, "attack_cooldown": 0.8,
		"scale_factor": 0.9, "tint": Color(0.85, 0.55, 0.2),
		"score": 20,
	},
	"tank": {
		"hp": 9, "damage": 2, "speed": 40.0,
		"attack_range": 52.0, "attack_cooldown": 1.6,
		"scale_factor": 1.4, "tint": Color(0.5, 0.3, 0.7),
		"score": 40,
	},
}

# ---------- DROPS (chance 0.0 - 1.0 per zombie death) ----------
const DROPS: Dictionary = {
	"medkit_chance": 0.10,   # heals 2 HP
	"heart_chance": 0.05,    # +1 max HP and heal
	"poison_chance": 0.14,   # +1 poison bottle
}

const MEDKIT_HEAL: int = 2

# ---------- BOSS ----------
# NERFED: -20% HP, slower attacks (+15% cooldowns), softer slam.
# NOTE: damage is integer-based, so throw stays at the 1-damage minimum
# (its pressure drops via the longer cooldown instead) and slam 1.6
# truncates to 1 (see below).
const BOSS: Dictionary = {
	"name": "THE SCIENTIST",
	"hp": 48,
	"speed": 95.0,
	"throw_damage": 1,
	"slam_damage": 1,
	"throw_cooldown": 2.53,
	"summon_cooldown": 10.35,
	"slam_cooldown": 5.75,
	"max_minions": 3,
}

# ---------- BOSS POISON DROPS (Scientist fight) ----------
# The Scientist periodically drops poison bottles the Prince can pick up
# and throw back. BOSS_POISON_DAMAGE is dealt per cloud tick
# (see POISON_CLOUD_TICK); the full splash lasts POISON_CLOUD_DURATION.
const BOSS_POISON_DROP_COOLDOWN: float = 18.0
const BOSS_POISON_FIRST_DELAY: float = 10.0
const BOSS_POISON_MAX_DROPS: int = 2
const BOSS_POISON_LIFETIME: float = 25.0
const BOSS_POISON_DAMAGE: int = 1

# ---------- LEVELS ----------
# Each level: {"name": str, "is_boss": bool, "waves": Array, "spawn_interval": float}
# Each wave: Dictionary of zombie_type -> count, e.g. {"walker": 3, "runner": 1}
# To add a level, append one entry. To add a wave, append one dict.
const LEVELS: Array = [
	{
		"name": "Level 1 - The Village Gate",
		"is_boss": false,
		"spawn_interval": 1.0,
		"waves": [
			{"walker": 3},
			{"walker": 3, "runner": 1},
		],
	},
	{
		"name": "Level 2 - Dark Forest",
		"is_boss": false,
		"spawn_interval": 0.9,
		"waves": [
			{"walker": 4, "runner": 1},
			{"walker": 3, "runner": 3},
			{"tank": 1, "walker": 3},
		],
	},
	{
		"name": "Level 3 - Ruined Town",
		"is_boss": false,
		"spawn_interval": 0.8,
		"waves": [
			{"walker": 4, "runner": 4},
			{"tank": 2, "walker": 4},
			{"tank": 1, "runner": 4, "walker": 3},
		],
	},
	{
		"name": "Level 4 - The Graveyard",
		"is_boss": false,
		"spawn_interval": 0.7,
		"waves": [
			{"walker": 5, "runner": 5, "tank": 2},
			{"tank": 3, "runner": 4},
			{"tank": 2, "runner": 6, "walker": 6},
		],
	},
	{
		"name": "Final Level - The Laboratory",
		"is_boss": true,
		"spawn_interval": 1.0,
		"waves": [],  # boss level ignores waves; boss summons its own minions
	},
]

# ---------- HELPERS ----------
static func level_count() -> int:
	return LEVELS.size()

static func get_level(idx: int) -> Dictionary:
	if idx < 0 or idx >= LEVELS.size():
		return LEVELS[0]
	return LEVELS[idx]

static func is_boss_level(idx: int) -> bool:
	return bool(get_level(idx).get("is_boss", false))

static func get_zombie(ztype: String) -> Dictionary:
	if ZOMBIES.has(ztype):
		return ZOMBIES[ztype]
	return ZOMBIES["walker"]

static func zombie_types() -> Array:
	return ZOMBIES.keys()
